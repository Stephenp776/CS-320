import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {
    @Test
    public void testTaskCreation() {
        Task task = new Task("12345", "Test Task", "This is a test description.");
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test description.", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Test Task", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Test Task", "Description"));
    }

    @Test
    public void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", null, "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "This name is way too long to be valid", "Description"));
    }

    @Test
    public void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "Test Task", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "Test Task", "This description is way too long to be valid and exceeds the character limit."));
    }
}